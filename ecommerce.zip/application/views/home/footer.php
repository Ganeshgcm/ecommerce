<!--footer oe uske csske file sari isme hai jo link ke thi-->



<!--footer  start-->
<style>

footer {
  background: #ff3d00 !important;
}
</style>
<footer class="page-footer">
  <div class="row" style="padding-left:10px; padding-right:10px;">
    <div class="col l6 m6 s12">
      <h6 class="center">
        <span class="fa fa-headset"></span>&nbsp;Contect Us
      </h6>
      <h5 class="center">+91 - 8802931278</h5>
      <p class="center">
        <span class="fa fa-envelope"></span>&nbsp;&nbsp;ganeshmishra1997@gmail.com
      </p>
      <div class="col l4 s12">
        <h5 class="white-text">Contect Information</h5>
        <p class="grey-text text-lighten-4">Ganesh Software Service <br />Delhi-110086 <br />India </p>
        <p>
          <span class="fa fa-envelope"></span>&nbsp;&nbsp;ganeshmishra1997@gmail.com
        </p>
      </div>
      <div class="col l4  s12">
        <h5 class="white-text">Links</h5>
        <ul>
          <li>
            <a class="grey-text text-lighten-3" href="<?php echo base_url("home/profile");?>">Company Profile</a>
          </li>

          <li>
            <a class="grey-text text-lighten-3" href="#!">User Login</a>
          </li>
          <li>
            <a class="grey-text text-lighten-3" href="#!">User Register</a>
          </li>
        </ul>
      </div>
      <div class="col l4  s12">
        <h5 class="white-text">Links</h5>
        <ul>
          <li>
            <a class="grey-text text-lighten-3" href="<?php echo base_url("home/profile");?>">Company Profile</a>
          </li>

          <li>
            <a class="grey-text text-lighten-3" href="<?php echo base_url("home/user_signin");?>">User Login</a>
          </li>
          <li>
            <a class="grey-text text-lighten-3" href="<?php echo base_url("home/user_signup");?>">User Register</a>
          </li>
        </ul>
      </div>
    </div>
  </div>


</footer>
